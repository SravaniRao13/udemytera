## This snippet is from the Debugging Terraform video.

```sh
export TF_LOG_PATH=/tmp/crash.log
export TF_LOG=TRACE
```
